This theme is meant to be an example theme for extending Boost.

It comes with maximum comments for all code and shows how to extend and add settings
to a Boost based theme.

It also looks nice!
